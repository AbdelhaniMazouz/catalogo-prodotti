package main.java.it.marconi.catalogoprodotti.controllers;
public class CatalogoController {

@GetMapping("/prodotto/nuovo")
public String nuovoProdotto(Model model) {
    model.addAttribute("product", new Product());
    return "prodotto_nuovo";
}

@PostMapping("/prodotto/nuovo")
public String nuovoProdotto(@ModelAttribute Product product) {
    catalogoService.addProduct(product);
    return "redirect:/catalogo";
}

@GetMapping("/prodotto/{code}")
public String prodottoDettaglio(@PathVariable String code, Model model) {
    Product product = catalogoService.getProduct(code);
    model.addAttribute("product", product);
    return "prodotto_dettaglio";
}

@PostMapping("/prodotto/{code}/delete")
public String deleteProduct(@PathVariable String code) {
    catalogoService.deleteProduct(code);
    return "redirect:/catalogo";


    }
}
